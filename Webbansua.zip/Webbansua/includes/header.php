<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
   <link rel="stylesheet" href="../assets/header.css"> 
<script src="../assets/javascript.js"></script>
</head>
<body><a style="text-decoration:none;" href="../index.php">
    <div class="header">
        <div class="title">Hãy Khám Phá Thế Giới Sữa</div>
        <div>
            <img src="../Image/logo1.png" alt="Logo 1" class="logo">
            <img src="../Image/logo2.png" alt="Logo 2" class="logo">
            <img src="../Image/logo3.png" alt="Logo 3" class="logo">
            <img src="../Image/logo4.png" alt="Logo 4" class="logo">
        </div>
    </div></a>


</body>
</html>