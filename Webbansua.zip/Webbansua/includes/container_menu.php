 <div class="container-menu">
        <!-- Menu Dọc -->
        <nav class="sidebar">
            <table class="menu-table">
                <tr>
                    <th><a href="index.php">Trang chủ</a></th>
                </tr>
                <tr>
                    <th><a href="products/danhmucsuabanchay.php">Bán chạy</a></th>
                </tr>
<tr>
          
          <th><a href="add_sua.php">Thêm sữa mới</a></th>
                </tr>

                <tr>
          
          <th><a href="tim_kiem.php">Tìm kiếm sữa</a></th>
                </tr>

                <tr>
                    <th><a href="add_khachhang.php">Thêm khách hàng</a></th>
                </tr>
            </table>
<div class="image">
<a href="#" target="_blank">
        <img src="../../Image/side1.jpg" alt="Hình ảnh 1" width=220px >
   </a>
 <a href="#" target="_blank">
        <img src="../../Image/side2.jpg" alt="Hình ảnh 2" width=220px >
   </a>
</div>
</nav>
<style>

.sidebar {
    width: 220px; 
    padding:0px;
margin:0
}

.sidebar a {
    display: block;
    
}

.sidebar img {
    width: 220px;  
    margin: 0 auto;  
}

.menu-table th {
    text-align: left;
    border:1px solid black;
    
}
.menu-table {
    width: 100%; 
    margin: 0;
    padding: 0; 
    border-collapse: collapse; 
}
.menu-table th, .menu-table td {
    padding: 0; 
}
.menu-table tr:nth-child(odd) {
    background-color: pink; 
}


.menu-table tr:nth-child(even) {
    background-color: #FFB6C1; 
}
.menu-table a {
    text-decoration: none;
    color: black;
    display: block;
    padding:10px;
}

.menu-table a:hover {
    background-color: #ff69b4;
    color: white;
}


.container-menu {
padding:0px;
display:flex;
flex-direction:row
}

</style>