
    <style>
        body{ 
margin:0 auto ;}
        footer {
            background-color: #FF69B4; 
            padding: 10px;
            text-align: center;
            color: white; 
            font-weight:bold;
            font-size:28px;
        }
        footer a {
            color: white; 
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline; 

        }

    </style>

    <footer>
        <p>&copy; 2024 Lê Thị Kim Ngân</p>
        <p><a href="#">Giới thiệu</a> | <a href="#">Liên hệ</a> | <a href="#">Chính sách bảo mật</a></p>
    </footer>