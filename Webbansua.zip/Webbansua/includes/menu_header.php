<div class="menu-head">
<ul>
<li><a href="../index.php">Trang Chủ</a></li>
<li><a href="../products/danhmucsuabanchay.php">Bán Chạy</a></li>
<li><a href="../products/danhmuc.php">Danh Muc</a>
<li><a href="../tim_kiem.php">Tìm Kiếm</a>
<li><a href="../add_khachhang.php">Thêm Khách Hàng</a>



</li>
</ul>
</div>
<link rel="stylesheet" href="../assets/header.css"> 