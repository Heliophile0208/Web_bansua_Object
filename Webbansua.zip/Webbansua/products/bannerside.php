<div class="image-links">
    <!-- Liên kết 1 -->
    <a href="#" target="_blank">
        <img src="../Image/side1.jpg" alt="Hình ảnh 1" width="100%">
    </a>
    
    <!-- Liên kết 2 -->
    <a href="#" target="_blank">
        <img src="../Image/side2.jpg" alt="Hình ảnh 2" width="100%">
    </a>
    
    <!-- Liên kết 3 -->
    <a href="#" target="_blank">
        <img src="../Image/side3.jpg" alt="Hình ảnh 3" width="100%">
    </a>
<a href="#" target="_blank">
        <img src="../Image/side4.jpg" alt="Hình ảnh 4" width="100%">
    </a>
</div>
 <style> 

.image-links {
    display: flex;
    flex-direction: column;  
    
}

.image-links a {
    text-decoration: none; 
}

.image-links img {
    width: 100px; 
    height: auto; 
    
}
</style>